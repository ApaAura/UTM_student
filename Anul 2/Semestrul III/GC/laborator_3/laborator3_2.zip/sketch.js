function setup() {
  createCanvas(600, 400);
  background(220);

  // Caroseria
  fill(50, 150, 255);
  stroke(0); 
  rect(100, 200, 400, 100, 20);

  // Partea superioară
  fill(50, 150, 255);
  rect(160, 120, 270, 80, 20);

  // Roți
  fill(0); 
  ellipse(180, 310, 100, 100); 
  ellipse(420, 310, 100, 100); 

  // Jantele 
  fill(150); 
  ellipse(180, 310, 60, 60); 
  ellipse(420, 310, 60, 60); 

  // Geamuri
  fill(255); 
  rect(215, 130, 60, 70, 10);
  rect(325, 130, 60, 70, 10); 

  // Faruri
  fill(255, 255, 100); 
  ellipse(120, 250, 30, 30); 
  ellipse(480, 250, 30, 30);

  fill(0);
  noStroke();
  textSize(16);
  textAlign(RIGHT, BOTTOM);
  text("Apareci Aurica, TI-231 FR", width - 10, height - 10);
}

function draw() {
  
}

