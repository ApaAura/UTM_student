function setup() {
  createCanvas(400, 400, WEBGL);
}

function draw() {
  background(230);

  // Sphere
  push();
  translate(-120, -120, 50);
  fill(50, 150, 255);    
  rotateZ(frameCount * 0.04);
  sphere(50);             
  pop();

  // Torus
  push();
  translate(120, -120, -50);
  fill(255, 180, 50);      
  rotateZ(frameCount * 0.01);
  torus(40, 15);         
  pop();

  // Cylinder
  push();
  translate(-120, 120, -30); 
  fill(50, 255, 150);        
  rotateX(frameCount * 0.01); 
  cylinder(40, 90);         
  pop();

  // Cone
  push();
  translate(120, 120, 30);  
  fill(255, 200, 100);       
  rotateY(frameCount * 0.01); 
  cone(40, 100);
  pop();
}
