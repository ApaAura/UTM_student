let armoredCar;

function preload() {

  armoredCar = loadModel('try.obj');
}
function setup() {
  createCanvas(800, 650, WEBGL);
}

function draw() {
  background(130);

  ambientLight(255);
  pointLight(0, 0, 255, 0, -200, 0);
  directionalLight(255, 255, 255, 0, 0, 1);


  specularMaterial(50, 150, 150);

  rotateX(frameCount * 0.01); 
  rotateY(frameCount * 0.02); 
  rotateZ(frameCount * 0.015); 

  translate(0, 120, 0);
  scale(80);
  rotate(PI);  

  model(armoredCar);
}