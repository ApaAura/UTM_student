function setup() {
  createCanvas(400, 400, WEBGL);
}

function draw() {
  background(230);

  // Sfera
  push();
  translate(-120, -120, 50); 
  fill(50, 150, 255);       
  sphere(50);               
  pop();

  // Tor
  push();
  translate(120, -120, -50); 
  fill(255, 180, 50);       
  torus(40, 15);            
  pop();

  // Cilindru
  push();
  translate(-120, 120, -30); 
  fill(50, 255, 150);        
  cylinder(40, 90);          
  pop();

  // Con
  push();
  translate(120, 120, 30);   
  fill(255, 200, 100);       
  cone(40, 100);             
  pop();
}
