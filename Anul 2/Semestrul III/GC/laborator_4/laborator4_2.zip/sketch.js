function preload()
{
  armoredCar = loadModel('armoredCar.obj');
}
function setup() 
{
  createCanvas(800, 650, WEBGL);
}
function draw() 
{
  background(130);
  ambientLight(255);
  pointLight(0,0,255,0,-200,0);
  directionalLight(255,255,255,0,0,1);
  specularMaterial(50,150,150);
  rotateX(radians(-20));
  rotateY(radians(20));
  translate(0,120,0);
  scale(80);
  rotate(PI);
  model(armoredCar);
}

